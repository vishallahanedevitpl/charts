## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

# Setup Environment

## Pre-requisite

# Install following tools:

1. node js

2. npm

## Get the code

## Go inside folder you have checkout repo

# Run following command in cmd same path

```
npm install
```

## To start the project

```
npm run start
```
